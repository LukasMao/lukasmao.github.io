% GROWTH_MODEL_SS.M
% This program computes the steady state of the model 

function [n,np,z,zp,k,kp,g,gp,c,cp,N,Z,K,G,C,chi] = growth_model_ss(betta,alfa,gama,delta_s);


% Steady state in levels
N = 1/3;
Z = 1;
K = ((1/betta + delta_s - 1)/alfa/Z/(N^(1-alfa)))^(1/(alfa-1));
G = Z*K^alfa*N^(1-alfa);
C = G - delta_s*K;
chi = (1-alfa)*Z*K^alfa*N^(-alfa)*C^(-gama); % weight of leisure in the utility function such that hours = 1/3 of endowment

% Steady state in logs
n = log(N);
z = log(Z); 
k = log(K);
g = log(G);
c = log(C);

% Future values
np = n;
zp = z;
kp = k;
gp = g;
cp = c;