% Comp.m
%(c) Francisco Ruge-Murcia (August 2011)

function [gmom,wtmat] = Comp(dt,optwt,maxq);


% Moments
nob = size(dt,1); % number of observations 
nvar = size(dt,2); % number of variables

for i = 1:nvar
    for j = i:nvar
        if (i==1) & (j==1)
            vars = dt(3:nob,i).*dt(3:nob,j);
        else
            vars = [vars dt(3:nob,i).*dt(3:nob,j)];  
        end
    end
end

autoc1 = dt(3:nob,:).*dt(2:nob-1,:);

global gmom
gmom = [mean(vars)';mean(autoc1)'];
