% ANAL-DERIV.M
function [fx,fxp,fy,fyp,fypyp,fypy,fypxp,fypx,fyyp,fyy,fyxp,fyx,fxpyp,fxpy,fxpxp,fxpx,fxyp,fxy,fxxp,fxx,...
    fypypyp,fypypy,fypypxp,fypypx,fypyyp,fypyy,fypyxp,fypyx,fypxpyp,fypxpy,fypxpxp,fypxpx,fypxyp,fypxy,fypxxp,fypxx,...
    fyypyp,fyypy,fyypxp,fyypx,fyyyp,fyyy,fyyxp,fyyx,fyxpyp,fyxpy,fyxpxp,fyxpx,fyxyp,fyxy,fyxxp,fyxx,...
    fxpypyp,fxpypy,fxpypxp,fxpypx,fxpyyp,fxpyy,fxpyxp,fxpyx,fxpxpyp,fxpxpy,fxpxpxp,fxpxpx,fxpxyp,fxpxy,fxpxxp,fxpxx,...
    fxypyp,fxypy,fxypxp,fxypx,fxyyp,fxyy,fxyxp,fxyx,fxxpyp,fxxpy,fxxpxp,fxxpx,fxxyp,fxxy,fxxxp,fxxx]=anal_deriv(f,x,y,xp,yp,approx); 

% This program copmutes analytical first and second (if approx=2) derivatives of the function f(yp,y,xp,x) with respect to x, y, xp, and yp.  
% For documentation, see the paper ``Solving Dynamic General Equilibrium Models Using a Second-Order Approximation to the Policy Function,'' by Stephanie Schmitt-Grohe and Martin Uribe (JEDC, vol. 28, January 2004, pp. 755-775). 
%
% Inputs: f, x, y, xp, yp, approx
% Output: Analytical first and second derivatives of f. 
%
% If approx is set at a value different from 2, the program delivers the first derivatives of f and sets second derivatives at zero. 
% If approx equals 2, the program returns first and second derivatives of f. The default value of approx is 2. 
% Note: This program requires MATLAB's Symbolic Math Toolbox
%
% (c) Stephanie Schmitt-Grohe and Martin Uribe
% Date July 17, 2001

nx = size(x,2);
ny = size(y,2);
nxp = size(xp,2);
nyp = size(yp,2);

n = size(f,1);

% Compute the first, second and third derivatives of f
fx = jacobian(f,x);
fxp = jacobian(f,xp);
fy = jacobian(f,y);
fyp = jacobian(f,yp);

if approx>1
    fypyp = reshape(jacobian(fyp(:),yp),n,nyp,nyp);   
    fypy = reshape(jacobian(fyp(:),y),n,nyp,ny);
    fypxp = reshape(jacobian(fyp(:),xp),n,nyp,nxp);
    fypx = reshape(jacobian(fyp(:),x),n,nyp,nx);
    fyyp = reshape(jacobian(fy(:),yp),n,ny,nyp);
    fyy = reshape(jacobian(fy(:),y),n,ny,ny);
    fyxp = reshape(jacobian(fy(:),xp),n,ny,nxp);
    fyx = reshape(jacobian(fy(:),x),n,ny,nx);
    fxpyp = reshape(jacobian(fxp(:),yp),n,nxp,nyp);
    fxpy = reshape(jacobian(fxp(:),y),n,nxp,ny);
    fxpxp = reshape(jacobian(fxp(:),xp),n,nxp,nxp);
    fxpx = reshape(jacobian(fxp(:),x),n,nxp,nx);
    fxyp = reshape(jacobian(fx(:),yp),n,nx,nyp);
    fxy = reshape(jacobian(fx(:),y),n,nx,ny);
    fxxp = reshape(jacobian(fx(:),xp),n,nx,nxp);
    fxx = reshape(jacobian(fx(:),x),n,nx,nx);
else
    fypyp=0; 
    fypy=0; 
    fypxp=0; 
    fypx=0; 
    fyyp=0; 
    fyy=0; 
    fyxp=0; 
    fyx=0; 
    fxpyp=0; 
    fxpy=0; 
    fxpxp=0; 
    fxpx=0; 
    fxyp=0; 
    fxy=0; 
    fxxp=0; 
    fxx=0;
end 

if approx>2
    fypypyp = reshape(jacobian(fypyp(:),yp),n,nyp,nyp,nyp); 
    fypypy =  reshape(jacobian(fypyp(:),y) ,n,nyp,nyp,ny);   
    fypypxp = reshape(jacobian(fypyp(:),xp),n,nyp,nyp,nxp);
    fypypx =  reshape(jacobian(fypyp(:),x) ,n,nyp,nyp,nx);
     
    fypyyp = reshape(jacobian(fypy(:),yp),n,nyp,ny,nyp);
    fypyy  = reshape(jacobian(fypy(:),y) ,n,nyp,ny,ny);
    fypyxp = reshape(jacobian(fypy(:),xp),n,nyp,ny,nxp);
    fypyx  = reshape(jacobian(fypy(:),x) ,n,nyp,ny,nx);
    
    fypxpyp = reshape(jacobian(fypxp(:),yp),n,nyp,nxp,nyp);
    fypxpy  = reshape(jacobian(fypxp(:),y) ,n,nyp,nxp,ny);
    fypxpxp = reshape(jacobian(fypxp(:),xp),n,nyp,nxp,nxp);
    fypxpx  = reshape(jacobian(fypxp(:),x) ,n,nyp,nxp,nx);
    
    fypxyp = reshape(jacobian(fypx(:),yp),n,nyp,nx,nyp);
    fypxy  = reshape(jacobian(fypx(:),y) ,n,nyp,nx,ny);
    fypxxp = reshape(jacobian(fypx(:),xp),n,nyp,nx,nxp);
    fypxx  = reshape(jacobian(fypx(:),x) ,n,nyp,nx,nx);
    
    fyypyp = reshape(jacobian(fyyp(:),yp),n,ny,nyp,nyp);
    fyypy  = reshape(jacobian(fyyp(:),y) ,n,ny,nyp,ny);
    fyypxp = reshape(jacobian(fyyp(:),xp),n,ny,nyp,nxp);
    fyypx  = reshape(jacobian(fyyp(:),x) ,n,ny,nyp,nx);
    
    fyyyp = reshape(jacobian(fyy(:),yp),n,ny,ny,nyp);
    fyyy  = reshape(jacobian(fyy(:),y) ,n,ny,ny,ny);
    fyyxp = reshape(jacobian(fyy(:),xp),n,ny,ny,nxp);
    fyyx  = reshape(jacobian(fyy(:),x) ,n,ny,ny,nx);
    
    fyxpyp = reshape(jacobian(fyxp(:),yp),n,ny,nxp,nyp);
    fyxpy  = reshape(jacobian(fyxp(:),y) ,n,ny,nxp,ny);
    fyxpxp = reshape(jacobian(fyxp(:),xp),n,ny,nxp,nxp);
    fyxpx  = reshape(jacobian(fyxp(:),x) ,n,ny,nxp,nx);
    
    fyxyp = reshape(jacobian(fyx(:),yp),n,ny,nx,nyp);
    fyxy  = reshape(jacobian(fyx(:),y) ,n,ny,nx,ny);
    fyxxp = reshape(jacobian(fyx(:),xp),n,ny,nx,nxp);
    fyxx  = reshape(jacobian(fyx(:),x) ,n,ny,nx,nx);
    
    fxpypyp = reshape(jacobian(fxpyp(:),yp),n,nxp,nyp,nyp);
    fxpypy  = reshape(jacobian(fxpyp(:),y) ,n,nxp,nyp,ny);
    fxpypxp = reshape(jacobian(fxpyp(:),xp),n,nxp,nyp,nxp);
    fxpypx  = reshape(jacobian(fxpyp(:),x) ,n,nxp,nyp,nx);
    
    fxpyyp = reshape(jacobian(fxpy(:),yp),n,nxp,ny,nyp);
    fxpyy  = reshape(jacobian(fxpy(:),y) ,n,nxp,ny,ny);
    fxpyxp = reshape(jacobian(fxpy(:),xp),n,nxp,ny,nxp);
    fxpyx  = reshape(jacobian(fxpy(:),x) ,n,nxp,ny,nx);
    
    fxpxpyp = reshape(jacobian(fxpxp(:),yp),n,nxp,nxp,nyp);
    fxpxpy  = reshape(jacobian(fxpxp(:),y) ,n,nxp,nxp,ny);
    fxpxpxp = reshape(jacobian(fxpxp(:),xp),n,nxp,nxp,nxp);
    fxpxpx  = reshape(jacobian(fxpxp(:),x) ,n,nxp,nxp,nx);
    
    fxpxyp = reshape(jacobian(fxpx(:),yp),n,nxp,nx,nyp);
    fxpxy  = reshape(jacobian(fxpx(:),y) ,n,nxp,nx,ny);
    fxpxxp = reshape(jacobian(fxpx(:),xp),n,nxp,nx,nxp);
    fxpxx  = reshape(jacobian(fxpx(:),x) ,n,nxp,nx,nx);
    
    fxypyp = reshape(jacobian(fxyp(:),yp),n,nx,nyp,nyp);
    fxypy  = reshape(jacobian(fxyp(:),y) ,n,nx,nyp,ny);
    fxypxp = reshape(jacobian(fxyp(:),xp),n,nx,nyp,nxp);
    fxypx  = reshape(jacobian(fxyp(:),x) ,n,nx,nyp,nx);
    
    fxyyp = reshape(jacobian(fxy(:),yp),n,nx,ny,nyp);
    fxyy  = reshape(jacobian(fxy(:),y) ,n,nx,ny,ny);
    fxyxp = reshape(jacobian(fxy(:),xp),n,nx,ny,nxp);
    fxyx  = reshape(jacobian(fxy(:),x) ,n,nx,ny,nx);
    
    fxxpyp = reshape(jacobian(fxxp(:),yp),n,nx,nxp,nyp);
    fxxpy  = reshape(jacobian(fxxp(:),y) ,n,nx,nxp,ny);
    fxxpxp = reshape(jacobian(fxxp(:),xp),n,nx,nxp,nxp);
    fxxpx  = reshape(jacobian(fxxp(:),x) ,n,nx,nxp,nx);
    
    fxxyp = reshape(jacobian(fxx(:),yp),n,nx,nx,nyp);
    fxxy  = reshape(jacobian(fxx(:),y) ,n,nx,nx,ny);
    fxxxp = reshape(jacobian(fxx(:),xp),n,nx,nx,nxp);
    fxxx  = reshape(jacobian(fxx(:),x) ,n,nx,nx,nx);
else
    fypypyp=0;
    fypypy=0;
    fypypxp=0;
    fypypx=0;
    fypyyp=0;
    fypyy=0;
    fypyxp=0;
    fypyx=0;
    fypxpyp=0;
    fypxpy=0;
    fypxpxp=0;
    fypxpx=0;
    fypxyp=0;
    fypxy=0;
    fypxxp=0;
    fypxx=0;
    fyypyp=0;
    fyypy=0;
    fyypxp=0;
    fyypx=0;
    fyyyp=0;
    fyyy=0;
    fyyxp=0;
    fyyx=0;
    fyxpyp=0;
    fyxpy=0;
    fyxpxp=0;
    fyxpx=0;
    fyxyp=0;
    fyxy=0;
    fyxxp=0;
    fyxx=0;
    fxpypyp=0;
    fxpypy=0;
    fxpypxp=0;
    fxpypx=0;
    fxpyyp=0;
    fxpyy=0;
    fxpyxp=0;
    fxpyx=0;
    fxpxpyp=0;
    fxpxpy=0;
    fxpxpxp=0;
    fxpxpx=0;
    fxpxyp=0;
    fxpxy=0;
    fxpxxp=0;
    fxpxx=0;
    fxypyp=0;
    fxypy=0;
    fxypxp=0;
    fxypx=0;
    fxyyp=0;
    fxyy=0;
    fxyxp=0;
    fxyx=0;
    fxxpyp=0;
    fxxpy=0;
    fxxpxp=0;
    fxxpx=0;
    fxxyp=0;
    fxxy=0;
    fxxxp=0;
    fxxx=0;
end 