% Wtmat.m
%(c) Francisco Ruge-Murcia (August 2011)

function [momm,wtmat] = Wtmat(dt,optwt,maxq);


% Moments
nob = size(dt,1); % number of observations 
nvar = size(dt,2); % number of variables

for i = 1:nvar
    for j = i:nvar
        if (i==1) & (j==1)
            vars = dt(2:nob,i).*dt(2:nob,j);
        else
            vars = [vars dt(2:nob,i).*dt(2:nob,j)];  
        end
    end
end

autoc1 = dt(2:nob,:).*dt(1:nob-1,:);

global momm
momm = [mean(vars)';mean(autoc1)'];

% Weighting matrix
if optwt > 0 % weigthing matrix is the optimal or its diagonal %
    nob = size(vars,1)+1;
	wm = (vars-(ones(size(vars,1),1)*mean(vars)))';
	wm = [wm;(autoc1-(ones(size(autoc1,1),1)*mean(autoc1)))'];
	wtmat = wm*wm';
	wtmat = wtmat/(nob-1);
	for iim = 1:maxq
		kapg = wm(:,iim+1:nob-1)*wm(:,1:nob-1-iim)';
		kapg = kapg + kapg';
		kapg = kapg/(nob-1);
		wtmat = wtmat + (1-iim/(maxq+1))*kapg;
    end
	if optwt == 1 % weigthing matrix is the diagonal of the optimal one %
		wtmat = diag(wtmat);
		wtmat = eye(size(wtmat,1)).*(wtmat*ones(1,size(wtmat,1)));
    end
else % weigthing matrix is the identity matrix %
	wtmat = eye(size(momm,1));
end

