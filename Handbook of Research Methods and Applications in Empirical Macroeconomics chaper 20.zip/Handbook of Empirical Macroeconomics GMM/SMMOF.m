% SMMOF.m
%(c) Francisco Ruge-Murcia (August 2011)

function vof = SMMOF(xx);



% READ INITIAL VALUES 
xx = real(xx);
global kp

if kp == 2
    betta = xx(1)/(1+xx(1));  % discount rate
    
    if xx(2) < 0;  % autoregressive coefficient of technology shock	
      rhoz = xx(2)/(1-xx(2));					
    else;
      rhoz = xx(2)/(1+xx(2));
    end 
else
    betta = xx(1);    
    rhoz = xx(2);
end	
sigz = abs(xx(3));  % standard deviation of innovation to tehcnology shock
gama = abs(xx(4));

alfa = 1/3;
delta_s = 0.02;
zbar = 1;  % unconditional mean of technology shock


% SOLUTION OF THE MODEL
eta  = [0 sigz]';

% Steady state
[N,N_p,Z,Z_p,K,K_p,Y,Y_p,C,C_p,Nbar,Zbar,Kbar,Ybar,Cbar,chi] = growth_model_ss(betta,alfa,gama,delta_s);
    
% Evaluate derivatives of function f
global approx
global fx fxp fy fyp nf

num_eval

% First-order approximation
[gx,hx] = gx_hx(nfy,nfx,nfyp,nfxp);

ne = size(eta,2); % number of shocks
nx = size(hx,1); % columns of x
ny = size(gx,1); % columns of y


% SIMULATE THE MODEL
global simsmp simdrop
bigt = simsmp + simdrop; % lenght of simulated series
eta = [0 1]';

% Path of innovations
pathe = zeros(ne,bigt);
s = [201108];
randn('state',s);
   
for t = 2:bigt
    pathe(1,t) = sigz*randn; % technology shock   
end

% Path of x
pathx1 = zeros(nx,bigt);
F11 = hx;
for t = 2:bigt
    s1 = eta*pathe(:,t);
    pathx1(:,t) = F11*pathx1(:,t-1) + s1;
end

% Path of y
pathy = zeros(ny,bigt);
FG1 = gx;
for t = 1:bigt
     pathy(:,t) = FG1*pathx1(:,t);
end

% Put simulated data together and compute simulated moments
simdata = [pathy(1,:)' pathy(2,:)'];
simdata = simdata(simdrop+1:size(simdata,1),:);
[gmom] = Comp(simdata);


% EVALUATE OBJECTIVE FUNCTION
global momm wtmat
vof = (gmom-momm)'*inv(wtmat)*(gmom-momm);

global matt1 npar kp
if kp == 3
    matt1 = gmom*ones(1,npar);
end

global matt2 jj
if kp == 4
	matt2(:,jj) = gmom;
end
