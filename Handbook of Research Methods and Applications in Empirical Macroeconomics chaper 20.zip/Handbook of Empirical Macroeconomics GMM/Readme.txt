Readme.txt

These programs replicate the Monte-Carlo study of the method of moments estimation of the Neoclassical growth
model in my paper "GMM Estimation of DSGE Models," written for the Handbook of Empirical Macroeconomics, 
N. Hashimzade and M. Thornton (eds.), Edward Elgar Publishing: Camberley, United Kingdom.

Results correspond to the first experiment in Table 1 (GMM) and in Table 5 (SMM).

The solution method also uses codes written by Stephanie Schmitt-Grohe and Martin Uribe. 
Their codes are distributed in this replication package with their permission.

These programs may be used or modified provided the original paper is cited and the original (c) notice is kept.

Should you encounter any problem or mistake, please contact me at francisco.ruge-murcia@umontreal.ca

(c) Francisco RUGE-MURCIA, 2011
