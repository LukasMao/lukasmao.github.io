% SGU.m
% Solution using the first-order perturbation   

function [data] = SGU(betta,alfa,gama,delta_s,rhoz,sigz,it,tt);
 

% Compute analytical derivatives
[fx,fxp,fy,fyp,f] = growth_model;

eta = [0 sigz]';

% Steady state
[N,N_p,Z,Z_p,K,K_p,Y,Y_p,C,C_p,Nbar,Zbar,Kbar,Ybar,Cbar,chi] = growth_model_ss(betta,alfa,gama,delta_s);
    
% Evaluate derivatives of function f
global approx
global fx fxp fy fyp nf

num_eval

% First-order approximation
[gx,hx] = gx_hx(nfy,nfx,nfyp,nfxp);

ne = size(eta,2); % number of shocks
nx = size(hx,1); % columns of x
ny = size(gx,1); % columns of y


% SIMULATE DATA
bigt = tt; % lenght of simulated series
eta = [0 1]';

% Path of innovations
pathe = zeros(ne,bigt);
randn('state',it);
   
for t = 2:bigt
    pathe(1,t) = sigz*randn; % technology shock   
end

% Path of x
pathx1 = zeros(nx,bigt);
F11 = hx;
for t = 2:bigt
    s1 = eta*pathe(:,t);
    pathx1(:,t) = F11*pathx1(:,t-1) + s1;
end

% Path of y
pathy = zeros(ny,bigt);
FG1 = gx;
for t = 1:bigt
     pathy(:,t) = FG1*pathx1(:,t);
end

% Put simulated data together
data = [pathy(1:3,:)'];



