% GMM
% This program replicates the Monte-Carlo study of the estimation of a DSGE model by GMM in my paper "GMM Estimation of DSGE Models,"
% written for the Handbook of Empirical Macroeconomics, N. Hashimzade and M. Thornton (Eds.), Edward Elgar Publishing: Camberley, United Kingdom.

%(c) Francisco Ruge-Murcia (August 2011)


clear all
warning off

nrep = 500; % number of replications 
it = 1;
crash = 0;  % 1 if previous study crashed, 0 otherwise 

% If previous study crashed 
if crash == 1;
	load coeff;
	load robsd;
	load jstat;
	it = length(coeff) + 1;
end
	

while it < nrep+1;
disp('');    
disp('ITERATION');;it

% GENERATE SAMPLE 
% Sample size 
    smp = 200;  % sample size 
    drop = 100;  % number of observations to be dropped 
    tt = drop + smp;  % total number of observations 
   
% Parameter values %
    alfa = 1/3;  % coeff. of capital in production function 
    betta =.96;  % discount rate 
    delta_s = .02; % depreciation rate   
    
    gama = 1;    % curvature parameter      
    rhoz = .5;  % AR coeff. of technology shock 
    sigz = .1;   % standard deviation of technology innovation 
	
% Select algorithm to  solve the model and generate data;
	global approx
	approx = 1;
	seed = floor(rand*10000);

    data = SGU(betta,alfa,gama,delta_s,rhoz,sigz,seed+it,tt);
	
% Select data used to estimate the model
	data = data(drop+1:tt,:);
	vv = 100*[data(:,1:2)];

    
% ESTIMATION    
% Compute data moments and weighting matrix
    global kp
    kp = 1;

    optq = 1;  % 1 if data-dependent, 0 if selected by user
    if optq == 0;
        maxq = 0;
    end
    if optq == 1;
        maxq = floor(4*(length(vv)/100)^(2/9));
    end

    optwt = 2;  % 2 if optimal, 1 if diagonal, 0 if identity
    wt = optwt;
    global momm wtmat  
    [momm,wtmat] = Wtmat(vv,optwt,maxq);  % data moments and weighting matrix
    nmom = length(momm);  % number of moments 

    
    % COMPUTE ANALYTICAL DERIVATIVES
	global fx fxp fy fyp nf
	[fx,fxp,fy,fyp,f] = growth_model;

    
% GMM 
    kp = 2;

% Starting values
    th = [betta rhoz sigz gama]';
    true = th;
    global npar
    npar = length(th);  % number of parameters 

% Reparameterize, if necessary 
    if kp == 2;	
  		th(1) = th(1)/(1-th(1));           
      	if th(2) < 0
      		th(2) = th(2)/(1+th(2));
        else
       		th(2) = th(2)/(1-th(2));
        end
    end
    
% Minimize objective function using fminunc
    options = optimset('Display','iter','LargeScale','on','MaxIter',5000,'MaxFunEvals',5000,'TolFun',1e-5);
    [xx, fval, exitflag] = fminunc(@GMMOF,th,options);
    if exitflag <= 0;
        disp('Algorithm did not converge');
        return
    end   

% Reparameterize back, if necessary 
    xx(1) = xx(1)/(1+xx(1));
    if xx(2) < 0	
     	xx(2) = xx(2)/(1-xx(2));	
    else
        xx(2) = xx(2)/(1+xx(2));
    end
    xx(3:4) = abs(xx(3:4));
    

% COMPUTE STANDARD ERRORS
    kp = 3;
    vof = GMMOF(xx);
    df = nmom - npar;  % degress of freedom %
    if df < 0
    	disp('Not enough degress of freedom');
    end

    stp = 1e-6;  % step to calculate derivative
    %stp = ones(npar,1)*stp;  % absolute step, if desired %
    stp = xx*stp;  % relative step, if desired

    global matt1 matt2 jj
    matt1 = zeros(nmom,npar);  % moments at the optimum %
    matt2 = zeros(nmom,npar);  % moments at the optimum + stp %
    matt = zeros(nmom,npar);  % Jacobian matrix %

    kp = 3;
    vof = GMMOF(xx);
    kp = 4;
    for jj = 1:npar;
    	em = zeros(npar,1);
       	em(jj,1) = stp(jj);
       	xxx = xx + em;
       	vof = GMMOF(xxx);
    end

    matt = matt2 - matt1;
    stp = kron(stp,ones(1,nmom))';
    matt = matt./stp;

    if optwt == 2;  % 2 if optimal, 1 if diagonal, 0 if identity  
    	rob = matt'*inv(wtmat)*matt;
    	robvg = inv(rob)/smp;
    else;
     	optwt = 2;  % compute optimal weighting matrix  
    	ww = wtmat;  % weighting matrix 
    	[momm wtmat] = Wtmat(vv,optwt,maxq);  % data moments and weighting matrix
    	robvg = inv(matt'*inv(ww)*matt)*matt'*inv(ww)*wtmat*inv(ww)*matt*inv(matt'*inv(ww)*matt)/smp;
    end

    
% SAVE RESULTS
    if it == 1;
	    coeff = xx';
 	    robsd = sqrt(diag(robvg))';
	    jstat = fval*smp;
    else;
        coeff = [coeff; xx'];
     	robsd = [robsd; sqrt(diag(robvg))'];
	    jstat = [jstat; (fval*smp)];
    end
    save coeff;
    save robsd;
    save jstat;
    
    it = it+1;
end    
     

% CALCULATE TYPE 1 ERROR 
xx = true;
table = -abs((coeff-ones(nrep,1)*xx')./robsd);
type1 = 0*table;
for i = 1:nrep
    for j = 1:npar
        if table(i,j) <= -1.96;
            type1(i,j) = 1;
        else
            type1(i,j) = 0;
        end
    end
end
type1 = sum(type1)/nrep;
sdtp = (type1.*(1-type1)/nrep).^(1/2);

 
% CALCULATE EMPIRICAL SIZE OF TEST OF OVERIDENTIFYING RESTRICTIONS @
jtest = chi2cdf(jstat,df);
size = 0*jtest;
for i = 1:nrep
    if jtest(i) <= 0.95;
        size(i) = 0;
    else
        size(i) = 1;
    end
end
size = sum(size)/nrep;
sdsize = (size*(1-size)/nrep)^.5;


% SAVE RESULTS
coeff8 = coeff;
robsd8 = robsd;
jstat8 = jstat;
save coeff8;
save robsd8;
save jstat8;
 

% PRINT ESTIMATES @
format short;
disp('GMM8.OUT');
disp('  ')
disp('Sample size');smp
disp('Number of replications');nrep
if wt == 0;
    disp('Weigthing Matrix = Identity');
end
if wt == 1;
    disp('Weigthing Matrix = Diagonal');
end
if wt == 2;
    disp('Weigthing Matrix = Optimal');
end
disp('  ')
disp('TRUE PARAMETERS');true'
disp('MONTE-CARLO RESULTS');
disp('Mean of estimated parameters');((sum(coeff)/nrep)')'
disp('Median of estimated parameters');(median(coeff))
disp('Mean asymptotic standard errors of estimates');((sum(robsd)/nrep)')'
disp('Standard deviation of estimates');(std(coeff))
disp('Type 1 error');type1
disp('Standard error of Type I');sdtp
disp('Actual size of test of overidentifying restrictions');size
disp('Standard error of size');sdsize

return