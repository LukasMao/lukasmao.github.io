% GMMOF.m
%(c) Francisco Ruge-Murcia (August 2011)

function vof = GMMOF(xx);



% READ INITIAL VALUES 
xx = real(xx);
global kp

if kp == 2
    betta = xx(1)/(1+xx(1));  % discount rate
    
    if xx(2) < 0;  % autoregressive coefficient of technology shock	
      rhoz = xx(2)/(1-xx(2));					
    else;
      rhoz = xx(2)/(1+xx(2));
    end 
else
    betta = xx(1);    
    rhoz = xx(2);
end	
sigz = abs(xx(3));  % standard deviation of innovation to tehcnology shock
gama = abs(xx(4));

alfa = 1/3;
delta_s = 0.02;
zbar = 1;  % unconditional mean of technology shock


% SOLUTION OF THE MODEL
eta  = [0 sigz]';

% Steady state
[N,N_p,Z,Z_p,K,K_p,Y,Y_p,C,C_p,Nbar,Zbar,Kbar,Ybar,Cbar,chi] = growth_model_ss(betta,alfa,gama,delta_s);
    
% Evaluate derivatives of function f
global approx
global fx fxp fy fyp nf

num_eval

% First-order approximation
[gx,hx] = gx_hx(nfy,nfx,nfyp,nfxp);

ne = size(eta,2); % number of shocks
nx = size(hx,1); % columns of x
ny = size(gx,1); % columns of y


% COMPUTE THEORETICAL MOMENTS (FOR THE SECOND-ORDER SOLUTION, DROP TERMS OF ORDER HIGHER THAN 2)
varshock = (eta*eta');

% All moments of x
meanx = zeros(nx,1);
varx = zeros(nx,nx);

C2 = varshock(:);
F22 = kron(hx,hx);
Qt = (eye(size(F22))-F22)\C2;
varx(:) = Qt;

% Variance-covariance matrix of y
vary = zeros(ny,ny);
vary(:) = kron(gx,gx)*varx(:);

% Covariance of y and x
varyx = gx*varx;

% Unconditional mean of y
meany = zeros(ny,1);

% First-order autocovariance of x
autox = hx*varx;

% First-order autocovariance of y
autoy = gx*autox*gx';

% Make sure all matrices are real valued
var_xx = real(varx);
var_yy = real(vary);
var_yx = real(varyx);
auto_x = diag(real(autox));
auto_y = diag(real(autoy));

% Select moments used for the estimation of the model
gmom = 100*100*[var_yy(1,1); var_yy(1,2); var_yy(2,2); auto_y(1); auto_y(2)];


% EVALUATE OBJECTIVE FUNCTION
global momm wtmat

vof = (gmom-momm)'*inv(wtmat)*(gmom-momm);

global matt1 npar kp
if kp == 3
    matt1 = gmom*ones(1,npar);
end

global matt2 jj
if kp == 4
	matt2(:,jj) = gmom;
end
