% GROWTH_MODEL.M
% This program describes the model 

function [fx,fxp,fy,fyp,f] = growth_model


% Define parameters
syms delta_s betta alfa gama chi rhoz

% Define variables 
syms Y C K N Z
syms Y_p C_p K_p N_p Z_p

% Write equations
f1 = Y - C - (K_p - (1-delta_s)*K);  % resource contraint 
f2 = Y - Z*K^alfa*N^(1-alfa);  % production function
f3 = C^(-gama) - betta*C_p^(-gama)*(1 + alfa*Z_p*K_p^(alfa-1)*N_p^(1-alfa) - delta_s);  % intertemporal FOC
f4 = chi*C^gama - (1-alfa)*Z*K^alfa*N^(-alfa);  % intratemporal FOC
f6 = log(Z_p) - rhoz*log(Z);  % technology shock process

% Create function f
f = [f1;f2;f3;f4;f6];

% Define the vector of controls, y, and states, x
x = [K Z];
y = [C N Y];
xp = [K_p Z_p];
yp = [C_p N_p Y_p];

% Make f a function of the logarithm of the state and control vector --  remember to change steady state and data accordingly
f = subs(f, [x,y,xp,yp], exp([x,y,xp,yp]));

% Compute analytical derivatives of f
global approx
[fx,fxp,fy,fyp] = anal_deriv(f,x,y,xp,yp,approx);

