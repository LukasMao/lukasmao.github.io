% SMM1
% This program performs a Monte-Carlo study of the estimation of a nonlinear DSGE model using SMM



clear all
warning off

load coeff1;
load coeff2;
load coeff3;


% PLOT RESULTS 
warning off;
li = 3;
col = 4;
subplot(li,col,1);hist(coeff1(:,1));
title('Beta');
subplot(li,col,2);hist(coeff1(:,2));
title('Rho');
subplot(li,col,3);hist(coeff1(:,3));
title('Sigma');
subplot(li,col,4);hist(coeff1(:,4));
title('Gamma');
subplot(li,col,5);hist(coeff2(:,1));
subplot(li,col,6);hist(coeff2(:,2));
subplot(li,col,7);hist(coeff2(:,3));
subplot(li,col,8);hist(coeff2(:,4));
subplot(li,col,9);hist(coeff3(:,1));
subplot(li,col,10);hist(coeff3(:,2));
subplot(li,col,11);hist(coeff3(:,3));
subplot(li,col,12);hist(coeff3(:,4));
disp('end')

return