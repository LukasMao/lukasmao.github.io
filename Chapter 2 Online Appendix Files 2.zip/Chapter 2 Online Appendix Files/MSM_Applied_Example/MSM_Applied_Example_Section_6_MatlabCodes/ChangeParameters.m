function [AveSimMoments, PS]=ChangeParameters(d,Teta,eps)

global K

%% Shift parameters one eps up and down
for i=1:d
    for j=1:2*d
        if fix((j+1)/2)==i  %  fix(X) rounds X to the nearest integers towards zero.
            PS(i,j)=Teta(i)*(1+ (rem(j,2)*2-1) * eps); % rem 求余运算
           % PS(i,j)=Teta(i)*(1+ (rem(j,2)*2-1) * eps);
        else
            PS(i,j)=Teta(i);
        end
    end
end

for i=1:2*d
    AveSimMoments(:,i)=SimulatedMoments(PS(:,i), K, 1);
end

end