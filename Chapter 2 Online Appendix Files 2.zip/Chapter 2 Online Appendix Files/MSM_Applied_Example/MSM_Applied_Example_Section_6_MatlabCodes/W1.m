function W_1=W1(EmpMoments)

W_1=diag(1./(EmpMoments).^2);

end