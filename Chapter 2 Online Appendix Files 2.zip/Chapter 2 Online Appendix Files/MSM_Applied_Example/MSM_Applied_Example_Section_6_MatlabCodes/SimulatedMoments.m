function [SimMoments,AllSimMoments]=SimulatedMoments(Teta, N, r)
 
SimulatedProfit=FirmExample(Teta, N, r, 0);
AllSimMoments=MomentSelection(SimulatedProfit, N);
SimMoments=sum(AllSimMoments,2)/N;
% S = sum(X,DIM) sums along the dimension DIM. 2 = add each row ; 
% 1 = add each column
% S = sum(X,'all') sums all elements of X.

end