function EmpMoments=EmpiricalMoments(TrueTeta,r)

Profit=FirmExample(TrueTeta, 1, r, 1);
% FirmExample(Teta, N, r, DataGen):
% N: number of simulation is used as 1.
%DataGen=0 for generating empirical moments
%DataGen=1 for generating simulated moments
% DataGen=1 : It's a flag to declare that empirical moments are generated.

% Output_Noise_ON=PinkNoise(Teta, N, r, DataGen); 
% Profit=firmsProfits(Teta, Output_Noise_ON, N, r, DataGen);


%% Moments selection
EmpMoments=MomentSelection(Profit, 1); 

end
