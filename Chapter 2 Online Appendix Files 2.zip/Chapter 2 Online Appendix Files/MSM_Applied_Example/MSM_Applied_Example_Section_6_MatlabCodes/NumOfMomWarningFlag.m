function FLAG=NumOfMomWarningFlag(Teta,Moments)

P=size(Moments,1);  % size(X,1) = number of rows
d=size(Teta,2);  % size(X,2) = number of columns

if P<d
    FLAG=2; % Error, P should be >= d
elseif P==d
    FLAG=1;
else
    FLAG=0;  
end

end