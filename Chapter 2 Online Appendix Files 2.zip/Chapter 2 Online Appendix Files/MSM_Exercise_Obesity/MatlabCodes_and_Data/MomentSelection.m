function moments=MomentSelection(X)

moments=[mean(X); std(X)]'; 

end